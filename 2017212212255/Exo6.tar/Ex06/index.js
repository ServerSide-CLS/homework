const express = require('express')
const app = express()
const fs = require('fs')

app.get('/time', (req, res) => {
    var now = new Date();
    var time = now.getFullYear()+'-'+(now.getMonth()+1)+'-'+now.getDate()+' '+now.getHours()+':'+now.getMinutes()+':'+now.getSeconds() 
    res.send(time)
})

app.post('/user', (req, res) => {
    var data = fs.readFileSync('/etc/passwd')
    data = data.toString().split('\n')
    var name = ''
    for(var i = 0;i < data.length;i++){
        if(data[i]!=''){
            name+=data[i].split(':')[0]+'\n'
        }
    }
    res.send(name)
})

app.get('/phone/:id', (req, res) => {
    let pattrn = /^(13[0-9]|15[0|1|3|6|7|8|9]|18[8|9])\d{8}$/
    if(pattrn.test(req.params.id))
        res.send('OK')
    else
        res.send('NO')
})

app.listen(3000, () => console.log('listening on port 3000'))