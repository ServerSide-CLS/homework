module.exports = {
    'product' :[{
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item1",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item2",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item3",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item4",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item5",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item6",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item7",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item8",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item9",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item10",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item11",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item12",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item13",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item14",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    },
    {
        "product-image":"http://localhost:3000/images/icon.png",
        "product-title":"item15",
        "product-des":"A coffeehouse, coffee shop, or caf&eacute; is an establishment which primarily serves hot coffee, related coffee beverages (e.g., caf&eacute; latte, cappuccino, espresso), tea, and other hot beverages. Some coffeehouses also serve cold beverages such as iced coffee and iced tea. Many caf&eacute;s also serve some type of food, such as light snacks, muffins, or pastries. Coffeehouses range from owner-operated small businesses to large multinational companies such as Starbucks.",
        "product-link":"aa"
    }
    ]

}