var express = require('express');
var router = express.Router();

router.get('/', function(req, res,next){
  let ret = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15',"16",'17','18','19','20','21','22','23','24','25','26','27','28','29','30','31',"32",'33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49']
  let total = []
  let total_two = []
  let count = ret.length
  let pagesize = 8
  var pageNumber = 1;
  let pageCount = Math.ceil(count/pagesize)
  pageNumber = req.query.pageNumber || 1

  if(pageNumber > pageCount){
    pageNumber = pageCount
  }

  if(pageNumber <= pageCount){
    for(var i = 0,j = (pageNumber-1)*8; i < 8, j < (pageNumber)*8; i++,j++){
      if(j < count){
        if(i < 4)
          total[i] = ret[j]
        else
          total_two[i] = ret[j]
      }
    }
  }

  if(pageNumber < 3){
    pageNumber = 2
  }

  pageNumber_add1 = parseInt(pageNumber)+1
  pageNumber_del1 = parseInt(pageNumber)-1

  res.render('form',{
    ret:  ret,
    total:     total,
    total_two:     total_two,
    pageCount:   pageCount,
    pageNumber:  pageNumber,
    pageNumber_add1: pageNumber_add1,
    pageNumber_del1: pageNumber_del1,
    count:       count
  })
})

module.exports = router;




